import{d as at}from"./redaction-D-lyttzB.js";import{c as G}from"./constants-BK-JjSa6.js";function u(t){const e=[];let r=t;for(;r&&r.nodeType===1;){if(r.id){e.unshift(`${r.tagName.toLowerCase()}[@id='${r.id}']`);break}let n=1;const l=r.tagName,M=r.parentElement;if(M)for(const I of Array.from(M.children)){if(I===r)break;I.tagName===l&&n++}if(e.unshift(`${r.tagName.toLowerCase()}[${n}]`),r===document.body)break;r=r.parentElement}return"/"+e.join("/")}let o=!1,d,s,_=null,T=0;function it(t,e){o||(d=t,s=e,o=!0,document.addEventListener("click",K),document.addEventListener("dblclick",R),document.addEventListener("contextmenu",D),(d.mouse_precision==="clicks_scroll_drag"||d.mouse_precision==="full_trajectory")&&(document.addEventListener("wheel",H),document.addEventListener("dragstart",Y),document.addEventListener("dragend",j)),d.mouse_precision==="full_trajectory"&&document.addEventListener("mousemove",P))}function ct(){o&&(o=!1,document.removeEventListener("click",K),document.removeEventListener("dblclick",R),document.removeEventListener("contextmenu",D),document.removeEventListener("wheel",H),document.removeEventListener("dragstart",Y),document.removeEventListener("dragend",j),document.removeEventListener("mousemove",P),_&&(cancelAnimationFrame(_),_=null))}function N(t){const e=t.target;return{selector:v(e),xpath:u(e),tag:e.tagName.toLowerCase(),text:at(e.textContent||"",d.redact_data)}}function v(t){return t.id?`#${t.id}`:t.className&&typeof t.className=="string"?`.${t.className.split(" ")[0]}`:t.tagName.toLowerCase()}function K(t){if(!o)return;const e=N(t);s("mouse",{action:"click",x:t.clientX,y:t.clientY,button:t.button,target_selector:e.selector,target_xpath:e.xpath,target_tag:e.tag,target_text:e.text})}function R(t){if(!o)return;const e=N(t);s("mouse",{action:"dblclick",x:t.clientX,y:t.clientY,button:t.button,target_selector:e.selector,target_xpath:e.xpath,target_tag:e.tag,target_text:e.text})}function D(t){if(!o)return;const e=N(t);s("mouse",{action:"contextmenu",x:t.clientX,y:t.clientY,button:t.button,target_selector:e.selector,target_xpath:e.xpath,target_tag:e.tag,target_text:e.text})}function H(t){if(!o)return;const e=t.target;s("mouse",{action:"wheel",x:t.clientX,y:t.clientY,button:0,target_selector:v(e),target_xpath:u(e),target_tag:e.tagName.toLowerCase(),target_text:""})}function Y(t){if(!o)return;const e=t.target;s("mouse",{action:"dragstart",x:t.clientX,y:t.clientY,button:t.button,target_selector:v(e),target_xpath:u(e),target_tag:e.tagName.toLowerCase(),target_text:""})}function j(t){if(!o)return;const e=t.target;s("mouse",{action:"dragend",x:t.clientX,y:t.clientY,button:t.button,target_selector:v(e),target_xpath:u(e),target_tag:e.tagName.toLowerCase(),target_text:""})}function P(t){if(!o)return;const e=performance.now();if(e-T<d.sample_rate_ms)return;T=e,_&&cancelAnimationFrame(_);const r=t.target;_=requestAnimationFrame(()=>{o&&s("mouse",{action:"mousemove",x:t.clientX,y:t.clientY,button:0,target_selector:v(r),target_xpath:u(r),target_tag:r.tagName.toLowerCase(),target_text:""})})}let g=!1,C,A;function st(t,e){g||t.keyboard_capture_mode!=="none"&&(C=t,A=e,g=!0,document.addEventListener("keydown",B),document.addEventListener("keyup",U))}function ut(){g&&(g=!1,document.removeEventListener("keydown",B),document.removeEventListener("keyup",U))}function F(t){const e=t.target;let r;return e.id?r=`#${e.id}`:e.className&&typeof e.className=="string"?r=`.${e.className.split(" ")[0]}`:r=e.tagName.toLowerCase(),{selector:r,xpath:u(e)}}function O(t){return t.ctrlKey||t.altKey||t.metaKey||t.shiftKey}function B(t){if(!g||C.keyboard_capture_mode==="shortcuts"&&!O(t))return;const e=F(t);A("keyboard",{action:"keydown",key:t.key,code:t.code,target_selector:e.selector,target_xpath:e.xpath,modifiers:{ctrl:t.ctrlKey,shift:t.shiftKey,alt:t.altKey,meta:t.metaKey}})}function U(t){if(!g||C.keyboard_capture_mode==="shortcuts"&&!O(t))return;const e=F(t);A("keyboard",{action:"keyup",key:t.key,code:t.code,target_selector:e.selector,target_xpath:e.xpath,modifiers:{ctrl:t.ctrlKey,shift:t.shiftKey,alt:t.altKey,meta:t.metaKey}})}let m=!1,W,f=null;function lt(t){m||(W=t,m=!0,document.addEventListener("scroll",z,{passive:!0}))}function dt(){m&&(m=!1,document.removeEventListener("scroll",z),f&&(clearTimeout(f),f=null))}function z(){m&&(f&&clearTimeout(f),f=setTimeout(()=>{m&&W("scroll",{scroll_x:window.scrollX,scroll_y:window.scrollY,scroll_height:document.documentElement.scrollHeight,scroll_width:document.documentElement.scrollWidth})},200))}let c=!1,$,L;function _t(t,e){c||($=t,L=e,c=!0,document.addEventListener("input",Q,!0),document.addEventListener("change",V,!0),document.addEventListener("focusin",Z,!0),document.addEventListener("focusout",tt,!0))}function ft(){c&&(c=!1,document.removeEventListener("input",Q,!0),document.removeEventListener("change",V,!0),document.removeEventListener("focusin",Z,!0),document.removeEventListener("focusout",tt,!0))}const gt=5;function mt(t){if(!t.className||typeof t.className!="string")return null;const e=t.className.trim().split(/\s+/).filter(r=>r.length>0);return e.length>0?e[0]:null}function pt(t){const e=t.parentElement;if(!e)return 1;let r=1;const n=t.tagName;for(const l of Array.from(e.children)){if(l===t)return r;l.tagName===n&&r++}return r}function ht(t){const e=t.tagName.toLowerCase(),r=mt(t),n=pt(t),l=r?`.${r}`:"";return`${e}${l}:nth-child(${n})`}function yt(t){const e=[];let r=t,n=0;for(;r&&r!==document.body&&r.nodeType===1&&n<gt;){if(r.id)return e.unshift(`#${r.id}`),e.join(" > ");e.unshift(ht(r)),r=r.parentElement,n++}return e.join(" > ")}function x(t){return{selector:yt(t),xpath:u(t),tag:t.tagName.toLowerCase()}}function J(t){return $.redact_data&&t instanceof HTMLInputElement&&t.type==="password"?"[REDACTED]":$.capture_input_values?t.value:"[DISABLED]"}function Q(t){if(!c)return;const e=t.target;if(!e)return;const r=x(e),n=J(e);L("dom_change",{action:"input",target_selector:r.selector,target_xpath:r.xpath,target_tag:r.tag,value:n})}function V(t){if(!c)return;const e=t.target;if(!e)return;const r=x(e),n=J(e);L("dom_change",{action:"change",target_selector:r.selector,target_xpath:r.xpath,target_tag:r.tag,value:n})}function Z(t){if(!c)return;const e=t.target;if(!e)return;const r=x(e);L("dom_change",{action:"focus",target_selector:r.selector,target_xpath:r.xpath,target_tag:r.tag,value:""})}function tt(t){if(!c)return;const e=t.target;if(!e)return;const r=x(e);L("dom_change",{action:"blur",target_selector:r.selector,target_xpath:r.xpath,target_tag:r.tag,value:""})}let p=!1,X,h=null;const et="__record_all_storage__",wt=`(function() {
    if (window.__record_all_storage_installed__) return;
    window.__record_all_storage_installed__ = true;
    var SIGNAL = '${et}';

    function post(storage_type, action, key, value_length) {
        try {
            window.postMessage({
                source: SIGNAL,
                storage_type: storage_type,
                action: action,
                key: key,
                value_length: value_length
            }, '*');
        } catch (e) {}
    }

    function wrap(storage, storage_type) {
        var orig_set = storage.setItem.bind(storage);
        var orig_remove = storage.removeItem.bind(storage);
        var orig_clear = storage.clear.bind(storage);

        storage.setItem = function(key, value) {
            try { post(storage_type, 'set', String(key), String(value == null ? '' : value).length); } catch (e) {}
            return orig_set(key, value);
        };
        storage.removeItem = function(key) {
            try { post(storage_type, 'remove', String(key), 0); } catch (e) {}
            return orig_remove(key);
        };
        storage.clear = function() {
            try { post(storage_type, 'clear', null, 0); } catch (e) {}
            return orig_clear();
        };
    }

    try { wrap(window.localStorage, 'local'); } catch (e) {}
    try { wrap(window.sessionStorage, 'session'); } catch (e) {}
})();`;function vt(){try{const t=document.createElement("script");t.textContent=wt,(document.documentElement||document.head||document.body).appendChild(t),t.remove()}catch{}}function Lt(t){p||(X=t,p=!0,vt(),h=e=>{if(!p||e.source!==window)return;const r=e.data;if(!r||r.source!==et)return;const n={storage_type:r.storage_type,action:r.action,key:r.key,value_length:typeof r.value_length=="number"?r.value_length:0};X("storage_change",n)},window.addEventListener("message",h,!0))}function Et(){p&&(p=!1,h&&(window.removeEventListener("message",h,!0),h=null))}const rt="__record_all_xhr_fetch__",xt=`(function() {
    if (window.__record_all_xhr_fetch_installed__) return;
    window.__record_all_xhr_fetch_installed__ = true;
    var SIGNAL = '${rt}';

    function post(type, method, url, status, duration) {
        try {
            window.postMessage({
                source: SIGNAL,
                request_type: type,
                method: method,
                url: url,
                status: status,
                duration_ms: duration
            }, '*');
        } catch (e) {}
    }

    // --- fetch wrapper ---
    var orig_fetch = window.fetch;
    window.fetch = function(input, init) {
        var method = (init && init.method) || 'GET';
        var url = typeof input === 'string' ? input : (input instanceof Request ? input.url : String(input));
        var start = performance.now();
        return orig_fetch.apply(this, arguments).then(function(response) {
            try { post('fetch', method, url, response.status, performance.now() - start); } catch (e) {}
            return response;
        }).catch(function(err) {
            try { post('fetch', method, url, 0, performance.now() - start); } catch (e) {}
            throw err;
        });
    };

    // --- XMLHttpRequest wrapper ---
    var orig_open = XMLHttpRequest.prototype.open;
    var orig_send = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function(method, url) {
        this.__record_all = { method: method, url: url, start: 0 };
        return orig_open.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function() {
        var self = this;
        var meta = this.__record_all;
        if (!meta) return orig_send.apply(this, arguments);
        meta.start = performance.now();

        var on_done = function() {
            try {
                post('xhr', meta.method, meta.url, self.status || 0, performance.now() - meta.start);
            } catch (e) {}
        };

        this.addEventListener('load', on_done, { once: true });
        this.addEventListener('error', on_done, { once: true });
        this.addEventListener('abort', on_done, { once: true });
        this.addEventListener('timeout', on_done, { once: true });

        return orig_send.apply(this, arguments);
    };
})();`;let y=!1,b,w=null;function bt(){try{const t=document.createElement("script");t.textContent=xt,(document.documentElement||document.head||document.body).appendChild(t),t.remove()}catch{}}function kt(t){y||(b=t,y=!0,bt(),w=e=>{if(!y||e.source!==window)return;const r=e.data;!r||r.source!==rt||(r.request_type==="fetch"?b("fetch_request",{method:r.method||"GET",url:r.url||"",status:typeof r.status=="number"?r.status:0,duration_ms:typeof r.duration_ms=="number"?Math.round(r.duration_ms*100)/100:0}):r.request_type==="xhr"&&b("xhr_request",{method:r.method||"GET",url:r.url||"",status:typeof r.status=="number"?r.status:0,duration_ms:typeof r.duration_ms=="number"?Math.round(r.duration_ms*100)/100:0}))},window.addEventListener("message",w,!0))}function $t(){y&&(y=!1,w&&(window.removeEventListener("message",w,!0),w=null))}let i=!1,S=0,k=window.location.href;window!==window.top&&(S=Math.floor(Math.random()*1e6));console.log("Record All: Content Script loaded at",window.location.href);chrome.runtime.onMessage.addListener((t,e,r)=>(console.log("Record All: Content received message:",t.action),t.action==="start"?(nt(t.config||G),r({success:!0})):t.action==="stop"?(Nt(),r({success:!0})):t.action==="ping"&&r({is_capturing:i,frame_id:S}),!0));chrome.runtime.sendMessage({action:"get_status"}).then(t=>{t!=null&&t.is_capturing&&!i&&(console.log("Record All: Recording already active, starting capture"),nt(t.config||G))}).catch(t=>{});function nt(t){i||(i=!0,console.log("Record All: Content capture started"),a("page_load",{load_time_ms:performance.timing.loadEventEnd-performance.timing.navigationStart,dom_content_loaded_ms:performance.timing.domContentLoadedEventEnd-performance.timing.navigationStart}),it(t,a),st(t,a),lt(a),_t(t,a),Lt(a),kt(a),document.addEventListener("visibilitychange",ot),window.addEventListener("popstate",E),window.addEventListener("hashchange",E),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",q):q())}function E(){if(!i)return;const t=window.location.href;if(t===k)return;const e=k;k=t,a("navigation",{from:e,to:t})}function q(){i&&a("dom_ready",{timestamp:Date.now()})}function Nt(){i&&(i=!1,ct(),ut(),dt(),ft(),Et(),$t(),document.removeEventListener("visibilitychange",ot),window.removeEventListener("popstate",E),window.removeEventListener("hashchange",E))}function ot(){i&&a("tab_switch",{action:document.hidden?"deactivate":"activate",tab_title:document.title})}function a(t,e){if(!i)return;const r={session_id:"",relative_time:performance.now(),absolute_time:Date.now(),type:t,data:e,tab_id:0,frame_id:S,url:window.location.href};chrome.runtime.sendMessage({action:"event",event:r}).catch(n=>{})}
